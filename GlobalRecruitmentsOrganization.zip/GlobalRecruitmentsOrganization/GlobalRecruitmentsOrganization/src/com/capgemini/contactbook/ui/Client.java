package com.capgemini.contactbook.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;


//import com.capgemini.dao;
import java.lang.NullPointerException;

@SuppressWarnings("unused")
public class Client  {

	static Scanner sc = new Scanner(System.in);
	static ContactBookService ContactBookService = null;
	static ContactBookServiceImpl contactBookServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean enqry = null;

		String Enquiry_id = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Global Recruitment Organization  ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Enquiry Details");
			System.out.println("2. View Enquiry Details on Id");
			System.out.println("3. Exit ");
			
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (enqry  == null) {
						enqry    = populateEnquiryBean ();
						 System.out.println(enqry);
						 
					}

					try {
						ContactBookService = new ContactBookServiceImpl();
						Enquiry_id = ContactBookService.addEnquiryDetails(enqry);

						System.out.println("cust details  has been successfully registered ");
						System.out.println("cust  ID Is: " + Enquiry_id);

					} finally {
						Enquiry_id = null;
						ContactBookService = null;
						enqry = null;
					}

					break;


					
				case 2:

					ContactBookService = new ContactBookServiceImpl();
					List<EnquiryBean> ContactBookList = new ArrayList<EnquiryBean>();
					ContactBookList = ContactBookService.retriveAll();

					if (ContactBookList != null) {
						Iterator<EnquiryBean> i = ContactBookList.iterator();
						while (i.hasNext()) {
							System.out.println(i.next());
						}
					} else {
						System.out
								.println("Nobody has Recruited.");
					}

					break;

					
					
					
				case 3:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}// end of while
	}

	
	   
	private static EnquiryBean populateEnquiryBean() throws Exception {

		// Reading and setting the values for the ContactBookBean
		
		EnquiryBean enqry = new EnquiryBean();

		System.out.println("\n Enquiry Details");

		System.out.println("Enter  First name: ");
		enqry.setfName(sc.next());
		System.out.println("Enter Last name: ");
		enqry.setlName(sc.next());
		System.out.println("Enter phone no: ");
		enqry.setContactNo(sc.next());
		System.out.println("Enter Domain interested: ");
		enqry.setpDomain(sc.next());
		System.out.println("Enter Loaction: ");
		enqry.setpDomain(sc.next());
		
	
		
        contactBookServiceImpl = new ContactBookServiceImpl();
//System.out.println("After creating ContactBook service impl object");

		ContactBookServiceImpl.validateContactBook(enqry);
		
		System.out.println("after validate ContactBook");
		return enqry ;
	

	}
}
