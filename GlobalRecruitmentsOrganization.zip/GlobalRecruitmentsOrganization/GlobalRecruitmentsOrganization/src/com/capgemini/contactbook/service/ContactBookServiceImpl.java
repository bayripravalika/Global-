package com.capgemini.contactbook.service;


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl  implements ContactBookService{
	
	ContactBookDao contactBookDao;
	
	public int addEnquiryDetails(EnquiryBean enqry) throws ContactBookException {
		
		contactBookDao= new ContactBookDaoImpl();
		
		int enquiry_Id_sequence;
		
		enquiry_Id_sequence = contactBookDao.addEnquiry(enqry);
		
		return enquiry_Id_sequence;
	}
	
	
	
	
		public void  validateEnquiry(EnquiryBean enqry) throws Exception
		{
			List<String> validationErrors = new ArrayList<String>();

			//Validating First name
			
			
			if(!(isValidfName(enqry.getfName()))) {
				validationErrors.add("\n contactBook Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			// validate Last name
			
			
			if(!(isValidlName(enqry.getlName()))) {
				validationErrors.add("\n contactBook Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			//Validating Phone Number
			
			
			if(!(isValidPhoneNumber(enqry.getContactNo()))){
				validationErrors.add("\n Phone Number Should be in 10 digit \n");
			}
			
			
			if(!validationErrors.isEmpty())
				throw new ContactBookException(validationErrors +"");
			}
		

		public boolean isValidfName(String name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			return nameMatcher.matches();
			}
		
		
		
		public boolean isValidlName(String name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			return nameMatcher.matches();
		}
			
			
		
           //This show whether the no. contain 10 digits or not//
		
		   public boolean isValidPhoneNumber(String phoneNumber){
			Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
			return phoneMatcher.matches();
			
		}
		
		   public boolean validatecontactBookId(String contactBook_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(contactBook_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}


		@Override
		public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookException {
			// TODO Auto-generated method stub
			return null;
		}


		@Override
		public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public void exitApplication() {
			// TODO Auto-generated method stub
			
		}




		@Override
		public String addEnquiryDetails1(EnquiryBean enqry) {
			// TODO Auto-generated method stub
			return null;
		}




		@Override
		public List<EnquiryBean> retriveAll() {
			// TODO Auto-generated method stub
			return null;
		}




		public static void validateContactBook(EnquiryBean enqry) {
			// TODO Auto-generated method stub
			
		}
}


		
