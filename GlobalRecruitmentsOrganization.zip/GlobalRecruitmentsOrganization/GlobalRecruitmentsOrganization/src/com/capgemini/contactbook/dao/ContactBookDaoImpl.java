package com.capgemini.contactbook.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;

public class ContactBookDaoImpl implements ContactBookDao {
	
	Logger logger=Logger.getRootLogger();
	
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resource//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addEnquiryDetails(EnquiryBean enqury) throws ContactBookException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String Enquiry_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, enqury.getfName());
			preparedStatement.setString(2, enqury.getlName());
			
			preparedStatement.setString(3, enqury.getContactNo());
			preparedStatement.setString(4, enqury.getpDomain());
			preparedStatement.setString(4, enqury.getpLocation());
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQUIRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				Enquiry_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new ContactBookException("Inserting Enquiry details failed ");

			}
			else
			{
				logger.info("Enquiry details added successfully:");
				return Enquiry_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		// TODO Auto-generated method stub
		return null;
	}

	public Object addEnquiryDetails(String enquirybean) {
		// TODO Auto-generated method stub
		return null;
	}

	

}

