package com.capgemini.contactbook.dao;

public interface QueryMapper {

	
	public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enqry_Id_sequence.NEXTVAL,?,?,?,?,?, (select SYSDATE from DUAL))";
	public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enquiry_Id_sequence.CURRVAL FROM DUAL";
	
	
}
